# Maintenance Notes — Module 6 Audit Harness

## Purpose and boundary

The Module 6 script audits, rather than modifies, the Module 5 Wikipedia agent. Keep this
separation intact: do not add mitigations, prompt rewrites, corpus edits, or production
workflow changes to `capstone_checkpoint_6_1_security_cost_starter.py`. Findings belong in
the JSONL log and written checkpoint analysis; improvements belong in a later Module 5
iteration.

## Dependencies on Module 5

The audit imports `Module 5/capstone_checkpoint_5_1_agent_rag_starter.py` by filesystem
path because Module 5 is not a Python package. `load_module_five()` registers the imported
module in `sys.modules`; this is required for LangGraph to resolve the Module 5 `TypedDict`
annotations.

The audit relies on these Module 5 components:

- `make_llm()` for the configured OpenRouter client
- `load_wikipedia_docs()` for the local corpus
- `WikipediaRetriever` for the retriever
- `WikipediaToolUsingAgent` for the actual LangGraph workflow

If any of these names or constructor signatures change, update `make_agent()` and run the
verification commands below.

## Measurement contract

`InstrumentedLLM` proxies `invoke()` without changing the agent interface. It classifies a
call as planner or answer by its system prompt and reads LangChain `usage_metadata`.
Missing provider usage data must remain zero/unknown; do not estimate tokens from text.

Cost is optional and calculated only from CLI-supplied current prices. Do not hard-code
OpenRouter model prices because they can change.

## Probe safety

`poison_copy()` uses `copy.deepcopy()` and appends the `AUDIT_PWNED` payload only to the
copy. Preserve this behavior. Never write security-probe text into `Module 5/Wikipedia/`.

The probe suite is intentionally small to limit API use. It provides evidence of observable
behavior, not a guarantee that the agent is secure. Review generated answers manually,
especially when the exact sentinel is absent.

## Logs and secrets

`checkpoint_6_1_audit.jsonl` contains user inputs and model responses. Review it before
committing or sharing. Do not log API keys, raw request headers, or environment variables.
The API key is owned by Module 5 configuration (`Module 5/.env` or an exported environment
variable) and must not be committed.

## Verification

From the repository root:

```bash
python -m py_compile "Module 6/capstone_checkpoint_6_1_security_cost_starter.py"
python "Module 6/capstone_checkpoint_6_1_security_cost_starter.py" --help
python "Module 6/capstone_checkpoint_6_1_security_cost_starter.py" --skip-probes
```

The final command makes live LLM calls and needs a valid OpenRouter key. For a no-network
code check, verify the import, `poison_copy()` isolation, and `InstrumentedLLM` usage
accounting with a mocked LLM.
