# Maintenance Notes — Production Wikipedia RAG Wrapper

## Scope

Module 7 is a wrapper around the Module 5 agent. It may construct sanitized in-memory
copies of articles, but it must never write to `Module 5/Wikipedia/` or modify the Module 5
source implementation as part of a request.

The imported Module 5 public interface is:

- `make_llm()`
- `load_wikipedia_docs()`
- `WikipediaRetriever`
- `WikipediaToolUsingAgent`

If any name or constructor changes, update `load_module_five()` or the call sites in
`ProductionWikipediaAgent` and run the smoke tests below.

## Safeguard invariants

Keep these properties when making changes:

1. Sanitize user text before route selection, cache lookup, retrieval, and prompts.
2. Deep-copy and sanitize article text before it reaches any Module 5 retriever or LLM.
3. Do not cache altered/sanitized input, context-dependent questions, or no-evidence answers.
4. Escape all data interpolated into the direct-path XML prompt.
5. Keep the input, article, cache, retry, and inherited Module 5 iteration limits bounded.
6. Record missing token metadata as unknown/zero; never invent usage values.

## Cache behavior

The cache is deliberately in memory, LRU-bounded, and TTL-limited. It is lost when the
process exits. This avoids persistent stale answers and protects user data, but it means
cross-process cache hits are not expected. The 0.92 token-Jaccard threshold is intentionally
conservative; lower it only after testing near-duplicate questions for incorrect reuse.

## Monitoring

`checkpoint_7_1_production.log` records the question, answer, path, calls, tokens, retry
count, and latency. Treat it as potentially sensitive operational data. Do not log API keys,
headers, or raw environment variables.

Watch for these signals:

- An increasing `full-agent` rate for simple questions may indicate router drift.
- Cache hits on semantically different questions indicate the similarity threshold is too low.
- Repeated retries indicate a provider availability issue.
- Sanitized inputs that produce poor answers may indicate over-aggressive patterns.

## Verification

Run from the repository root:

```bash
python -m py_compile "Module 7/capstone_checkpoint_7_1_production_ready_starter.py"
python "Module 7/capstone_checkpoint_7_1_production_ready_starter.py" --help
python "Module 7/capstone_checkpoint_7_1_production_ready_starter.py" \
  --question "Who won the 1984 NBA Finals?" --repeat
```

The last command makes live LLM calls and needs the Module 5 OpenRouter configuration.
