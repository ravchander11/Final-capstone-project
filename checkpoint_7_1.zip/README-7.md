# Module 7 — Production-Ready Wikipedia RAG Agent

`capstone_checkpoint_7_1_production_ready_starter.py` is a production wrapper around
the Module 5 Wikipedia LangGraph agent. It applies the security and efficiency ideas from
Labs 7.1 and 7.2 to the real local Wikipedia corpus rather than a sample corpus.

## Architecture

```text
raw question
  → input sanitization and length limit
  → eligible clean repeat? → bounded similarity cache
  → deterministic router
       ├─ direct: local search + one structured answer call
       └─ full-agent: sanitized Module 5 LangGraph workflow
  → answer + per-request metrics + log
```

The wrapper imports `Module 5/capstone_checkpoint_5_1_agent_rag_starter.py`, loads its
local Wikipedia HTML corpus, and never modifies the source files in `Module 5/Wikipedia/`.

## Implemented security safeguards

| Safeguard | Implementation | Risk addressed |
| --- | --- | --- |
| Input bound | `MAX_USER_CHARS = 2,000` | Oversized inputs that increase context, latency, and cost. |
| User-input sanitization | `sanitize_user_question()` removes pasted source/article blocks and instruction-like phrases before routing, retrieval, caching, and prompts. | Direct prompt injection and fake sources steering retrieval. |
| XML escaping | `escape_xml()` escapes user and article text before the structured direct prompt is created. | Users or documents forging `<documents>` or `<user_question>` boundaries. |
| Retrieved-text sanitization | `safe_docs()` deep-copies documents; `sanitize_article_text()` neutralizes instruction-shaped text in the copy. | Indirect prompt injection hidden in a retrieved Wikipedia article. |
| Explicit trust boundary | `DIRECT_ANSWER_SYSTEM` accepts evidence only from `<documents>` and treats `<user_question>` as untrusted data. | Roleplay, command, and source-confusion attacks. |
| Bounded retries | `ResilientInstrumentedLLM` retries a failed model call at most twice with short backoff. | Transient provider failures without unbounded retry cost. |
| Existing Module 5 limits | The full path retains its retrieval, context, and iteration caps. | Runaway tool use and context growth. |

Sanitization is a defense-in-depth control, not proof against every adversarial string or
multi-turn attack. The full-agent path should continue to be exercised with the Module 6
security probes.

## Implemented performance optimizations

| Optimization | Implementation | Trade-off |
| --- | --- | --- |
| Bounded similarity cache | `SimilarityAnswerCache` uses a high token-Jaccard threshold (0.92), 30-minute TTL, and 256-entry LRU cap. | It only caches clean, self-contained turns; this reduces cache-hit rate but avoids context-dependent/stale answers. |
| Direct route | `route()` sends short, single-topic, clean questions to one local search plus one answer call. | Complex, ambiguous, long, or sanitized questions use the slower full agent to preserve quality. |
| Deterministic routing | The router is plain Python rather than another LLM call. | Less flexible than an LLM router, but adds zero model tokens or router latency. |
| Context trimming | Direct retrieval returns at most three articles, each capped at 5,000 characters. | A low context cap can omit useful evidence for complex questions; those are routed to the full agent. |
| Metrics | `RequestMetrics` tracks route, cache hit, sanitization, planner/answer calls, tokens, latency, and retries. | Provider token metadata may be unavailable; zero is recorded rather than guessed. |

## Setup

Use Python 3.11 or 3.12.

The wrapper imports the Module 5 agent at runtime. Its four runtime packages are pinned in
`requirements.txt`; no vector database or embedding package is required for the Module 7
in-memory cache and deterministic router.

```bash
cd "Module 7"
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Create `Module 5/.env` with a valid OpenRouter key:

```env
OPENROUTER_API_KEY=sk-or-v1-...
```

`langchain-openai` supplies the OpenRouter-compatible chat client used by the imported
Module 5 agent. Provider token metadata is optional: when it is unavailable, metrics report
zero tokens rather than estimating them.

## Run and collect evidence

Run one question:

```bash
python "Module 7/capstone_checkpoint_7_1_production_ready_starter.py" \
  --question "Who won the 1984 NBA Finals?"
```

Run the same eligible question twice to compare cache miss and cache hit:

```bash
python "Module 7/capstone_checkpoint_7_1_production_ready_starter.py" \
  --question "Who won the 1984 NBA Finals?" --repeat
```

The second request should report `path=cache-hit`, `calls=0`, and `tokens=0` for the
in-process cache. Each request is logged to `Module 7/checkpoint_7_1_production.log` with
the answer and metrics. Review logs before sharing them because they contain user questions
and model outputs.

## Production plan for the worksheet

`my_production_plan()` in the implementation returns the exact safeguards,
optimizations, measurable gains, and residual risks used in this system. The primary
measurement comparison is:

- Direct cache miss: one answer-model call after local retrieval.
- Full-agent path: one or more planner calls plus an answer-model call.
- Eligible cache hit: no LLM call.

Do not claim fixed latency, token, or cost values without using the per-request log from
your own run; API-provider usage and latency vary by model and time.
