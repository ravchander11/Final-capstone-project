r"""Capstone Checkpoint 5.1 — tool-using RAG agent over the local Wikipedia corpus.

Run: python capstone_checkpoint_5_1_agent_rag_starter.py --question "Who won the 1984 NBA Finals?"
The control flow mirrors Lab 5.2: plan -> a selected tool -> plan -> answer.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Optional, TypedDict
from urllib.parse import unquote, urlparse

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
LLM_MODEL = "openai/gpt-5.4-mini"
TEMPERATURE = 0.2
SCENARIO = "wikipedia"
WIKIPEDIA_DIR = Path(__file__).resolve().parent / "Wikipedia"
LOG_PATH = Path(__file__).resolve().parent / "checkpoint_5_1_agent.log"
TOP_K, MAX_ITERATIONS, MAX_ARTICLE_CHARS, MAX_CONTEXT_ARTICLES = 4, 5, 6_000, 8

ANSWER_SYSTEM = """You are a Wikipedia research assistant. Answer only from the
provided local Wikipedia articles. Cite evidence using article titles in square brackets.
If the articles do not support an answer, say the local corpus has insufficient evidence.
Do not use outside knowledge or invent quotations."""

PLAN_SYSTEM = """You plan a local Wikipedia research agent. Given the question,
previous actions, and retrieved articles, return ONLY this JSON object:
{"action":"search"|"article"|"links"|"clarify"|"answer",
 "queries":["one or two NEW search queries"], "title":"known article title or id",
 "source_id":"retrieved article id", "clarification":"short question",
 "reasoning":"brief explanation"}

Actions: search finds relevant local articles; article performs deterministic lookup of
a named title; links follows local Wikipedia links from an already retrieved article;
clarify is a last resort after search; answer only when evidence supports it or no useful
retrieval remains. Never repeat a past action. Do not state facts from your general
knowledge in reasoning: reasoning describes the next tool choice, not an answer.
Never choose answer before at least one local article has been retrieved."""


def check_api_key() -> str:
    load_dotenv(Path(__file__).resolve().parent / ".env")
    load_dotenv()
    key = os.getenv("OPENROUTER_API_KEY", "").strip()
    if not key:
        raise RuntimeError("OPENROUTER_API_KEY is not set; add it to a .env file next to this script.")
    if not key.startswith("sk-or-"):
        raise RuntimeError(
            "OPENROUTER_API_KEY is not an OpenRouter key. Replace it with an OpenRouter "
            "key beginning 'sk-or-' from https://openrouter.ai/keys."
        )
    return key


def make_llm() -> ChatOpenAI:
    return ChatOpenAI(model=LLM_MODEL, temperature=TEMPERATURE,
                      api_key=check_api_key(), base_url=OPENROUTER_BASE_URL)


def log(label: str, text: str) -> None:
    with LOG_PATH.open("a", encoding="utf-8") as out:
        out.write(f"[{datetime.now().isoformat(timespec='seconds')}] {label}\n{text}\n{'-' * 72}\n")


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def clean_html(raw: str) -> str:
    raw = re.sub(r"<script.*?</script>|<style.*?</style>", " ", raw, flags=re.I | re.S)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", raw))).strip()


def local_article_id(href: str, available: set[str]) -> Optional[str]:
    path = urlparse(html.unescape(href)).path
    if "/wiki/" not in path:
        return None
    article_id = unquote(path.split("/wiki/", 1)[1]).replace("/", "_") + ".html"
    return article_id if article_id in available else None


def load_wikipedia_docs(corpus_dir: Path = WIKIPEDIA_DIR) -> dict[str, dict[str, Any]]:
    """Read local HTML articles, retaining title, cleaned text, and local hyperlinks."""
    if not corpus_dir.is_dir():
        raise FileNotFoundError(f"Wikipedia corpus directory not found: {corpus_dir}")
    paths = sorted(corpus_dir.glob("*.html"))
    available = {p.name for p in paths}
    docs: dict[str, dict[str, Any]] = {}
    for path in paths:
        raw = path.read_text(encoding="utf-8", errors="replace")
        match = re.search(r"<title[^>]*>(.*?)</title>", raw, flags=re.I | re.S)
        title = clean_html(match.group(1)) if match else path.stem.replace("_", " ")
        title = re.sub(r"\s*-\s*Wikipedia\s*$", "", title, flags=re.I)
        links = sorted({target for href in re.findall(r"href=[\"']([^\"']+)", raw, flags=re.I)
                        if (target := local_article_id(href, available)) and target != path.name})
        docs[path.name] = {"id": path.name, "title": title, "text": clean_html(raw), "links": links}
    return docs


class WikipediaRetriever:
    """Local lexical search, exact article lookup, and one-hop link traversal tools."""
    def __init__(self, docs: dict[str, dict[str, Any]]):
        self.docs = docs
        self.tokens = {doc_id: tokenize(f"{d['title']} {d['text']}") for doc_id, d in docs.items()}
        self.title_index = {self.normalise(doc_id): doc_id for doc_id in docs}
        self.title_index.update({self.normalise(d["title"]): doc_id for doc_id, d in docs.items()})

    @staticmethod
    def normalise(value: str) -> str:
        return " ".join(tokenize(unquote(value).replace("_", " ").removesuffix(".html")))

    def search(self, query: str, k: int = TOP_K) -> list[str]:
        terms = set(tokenize(query))
        scored = []
        for doc_id, words in self.tokens.items():
            counts, overlap = Counter(words), terms & set(words)
            if overlap:
                title_overlap = len(terms & set(tokenize(self.docs[doc_id]["title"])))
                scored.append((doc_id, sum(1 + min(counts[t], 3) for t in overlap) + 3 * title_overlap))
        return [doc_id for doc_id, _ in sorted(scored, key=lambda x: (-x[1], x[0]))[:k]]

    def find_article(self, title: str) -> Optional[str]:
        wanted = self.normalise(title)
        if wanted in self.title_index:
            return self.title_index[wanted]
        matches = sorted({doc_id for key, doc_id in self.title_index.items() if wanted and wanted in key})
        return matches[0] if matches else None

    def follow_links(self, source_id: str, k: int = TOP_K) -> list[str]:
        return self.docs.get(source_id, {}).get("links", [])[:k]


class AgentState(TypedDict):
    conversation_history: list[dict[str, str]]
    clarification_history: list[str]
    pending_queries: list[str]
    pending_title: str
    pending_source_id: str
    executed_actions: list[str]
    articles: dict[str, dict[str, Any]]
    iterations: int
    mode: str
    next_action: str
    clarification_question: str
    answer: str
    done: bool


class WikipediaToolUsingAgent:
    def __init__(self, retriever: WikipediaRetriever, llm: ChatOpenAI, debug: bool = True):
        self.retriever, self.llm, self.debug = retriever, llm, debug
        self.graph = self._build_graph()

    def article_context(self, articles: dict[str, dict[str, Any]]) -> str:
        return "\n\n---\n\n".join(
            f"[{doc_id} | {article['title']}]\n{article['text'][:MAX_ARTICLE_CHARS]}"
            for doc_id, article in list(articles.items())[:MAX_CONTEXT_ARTICLES]
        ) or "(none yet)"

    @staticmethod
    def parse_json(response: Any) -> dict[str, Any]:
        raw = str(getattr(response, "content", response)).strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except (json.JSONDecodeError, ValueError):
            return {}

    def _build_graph(self):
        def search_node(state: AgentState) -> dict[str, Any]:
            articles, executed = dict(state["articles"]), list(state["executed_actions"])
            for query in state["pending_queries"][:2]:
                hits = self.retriever.search(query)
                if self.debug: print(f"[agent] search {query!r} -> {[self.retriever.docs[i]['title'] for i in hits]}")
                articles.update({doc_id: self.retriever.docs[doc_id] for doc_id in hits})
                executed.append(f"SEARCH:{query}")
            return {"articles": articles, "executed_actions": executed, "pending_queries": [], "iterations": state["iterations"] + 1}

        def article_node(state: AgentState) -> dict[str, Any]:
            doc_id, articles = self.retriever.find_article(state["pending_title"]), dict(state["articles"])
            if doc_id: articles[doc_id] = self.retriever.docs[doc_id]
            if self.debug: print(f"[agent] article {state['pending_title']!r} -> {doc_id or 'not found'}")
            return {"articles": articles, "pending_title": "", "iterations": state["iterations"] + 1,
                    "executed_actions": state["executed_actions"] + [f"ARTICLE:{state['pending_title']}"]}

        def links_node(state: AgentState) -> dict[str, Any]:
            source, articles = state["pending_source_id"], dict(state["articles"])
            hits = self.retriever.follow_links(source)
            articles.update({doc_id: self.retriever.docs[doc_id] for doc_id in hits})
            if self.debug: print(f"[agent] links from {source!r} -> {[self.retriever.docs[i]['title'] for i in hits]}")
            return {"articles": articles, "pending_source_id": "", "iterations": state["iterations"] + 1,
                    "executed_actions": state["executed_actions"] + [f"LINKS:{source}"]}

        def plan_node(state: AgentState) -> dict[str, Any]:
            # A deterministic first retrieval prevents the planner from answering from
            # parametric knowledge before it has seen any local-corpus evidence.
            if not state["articles"] and not state["executed_actions"]:
                question = state["clarification_history"][0]
                if self.debug: print(f"[agent] action=search (mandatory initial retrieval)")
                return {"next_action": "search", "pending_queries": [question],
                        "pending_title": "", "pending_source_id": ""}
            if state["iterations"] >= MAX_ITERATIONS:
                return {"next_action": "answer", "pending_queries": [], "pending_title": "", "pending_source_id": ""}
            conversation = "\n".join(f"{m['role'].title()}: {m['content']}" for m in state["conversation_history"][-6:]) or "(none)"
            executed = "\n".join(f"- {a}" for a in state["executed_actions"]) or "(none)"
            prompt = (f"Prior conversation:\n{conversation}\n\nQuestion and clarifications:\n{'\n'.join(state['clarification_history'])}\n\n"
                      f"Actions already executed:\n{executed}\n\nRetrieved articles:\n{self.article_context(state['articles'])}")
            result = self.parse_json(self.llm.invoke([SystemMessage(content=PLAN_SYSTEM), HumanMessage(content=prompt)]))
            action = str(result.get("action", "answer"))
            if self.debug:
                print(f"[agent] action={action} (planner rationale is not corpus evidence)")
            queries = result.get("queries", [])
            return {"next_action": action, "pending_queries": queries if isinstance(queries, list) else [],
                    "pending_title": str(result.get("title", "")), "pending_source_id": str(result.get("source_id", "")),
                    "clarification_question": str(result.get("clarification", "Could you clarify your question?"))}

        def clarify_node(state: AgentState) -> dict[str, Any]:
            clarification, history = state["clarification_question"], list(state["clarification_history"])
            if state["mode"] == "chat":
                print(f"\nAssistant: {clarification}")
                history.append(f"Q: {clarification}\nA: {input('You: ').strip()}")
            else: history.append(f"Q: {clarification}\nA: (no clarification available in batch mode)")
            return {"clarification_history": history, "clarification_question": ""}

        def answer_node(state: AgentState) -> dict[str, Any]:
            if not state["articles"]:
                return {"answer": "I could not find relevant evidence in the local Wikipedia corpus to answer that question.", "done": True}
            prompt = f"Question and clarifications:\n{'\n'.join(state['clarification_history'])}\n\nRetrieved articles:\n{self.article_context(state['articles'])}"
            response = self.llm.invoke([SystemMessage(content=ANSWER_SYSTEM), HumanMessage(content=prompt)])
            return {"answer": str(getattr(response, "content", response)), "done": True}

        def route(state: AgentState) -> str:
            if state["next_action"] == "search" and state["pending_queries"]: return "search"
            if state["next_action"] == "article" and state["pending_title"]: return "article"
            if state["next_action"] == "links" and state["pending_source_id"] in state["articles"]: return "links"
            return "clarify" if state["next_action"] == "clarify" else "answer"

        graph = StateGraph(AgentState)
        for name, fn in [("plan", plan_node), ("search", search_node), ("article", article_node), ("links", links_node), ("clarify", clarify_node), ("answer", answer_node)]: graph.add_node(name, fn)
        graph.set_entry_point("plan")
        for name in ("search", "article", "links", "clarify"): graph.add_edge(name, "plan")
        graph.add_conditional_edges("plan", route)
        graph.add_edge("answer", END)
        return graph.compile()

    def _run(self, question: str, mode: str, history: Optional[list[dict[str, str]]] = None) -> str:
        state: AgentState = {"conversation_history": history or [], "clarification_history": [question], "pending_queries": [], "pending_title": "", "pending_source_id": "", "executed_actions": [], "articles": {}, "iterations": 0, "mode": mode, "next_action": "plan", "clarification_question": "", "answer": "", "done": False}
        return self.graph.invoke(state)["answer"]

    def query(self, question: str) -> str:
        return self._run(question, "batch")

    def chat(self) -> None:
        print("Wikipedia tool-using RAG agent. Type 'exit' or 'quit' to stop.\n")
        history: list[dict[str, str]] = []
        while True:
            question = input("You: ").strip()
            if question.lower() in {"exit", "quit"}: print("Goodbye."); return
            if not question: continue
            try: answer = self._run(question, "chat", history)
            except Exception as error: print(f"Error: {error}"); continue
            print(f"\nAssistant: {answer}\n")
            log("AGENTIC", f"Q: {question}\nA: {answer}")
            history.extend(({"role": "user", "content": question}, {"role": "assistant", "content": answer}))


def my_agent_plan() -> dict[str, Any]:
    return {"tools": ["search", "article", "links", "clarify", "answer"],
            "stop_condition": "Retrieved passages support every part of the question, or useful local retrieval paths are exhausted.",
            "system_prompt_idea": "Search first; use title lookup for named pages and links for connected evidence; answer only with local-corpus citations.",
            "test_tasks": ["Who won the 1984 NBA Finals, and whom did they defeat?", "What caused the 1955 Le Mans disaster and what safety changes followed?", "How did the 1964 Alaska earthquake compare with other major earthquakes?"]}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the tool-using Wikipedia RAG agent.")
    parser.add_argument("--question", help="Run one non-interactive question.")
    parser.add_argument("--no-debug", action="store_true", help="Hide planning decisions.")
    args = parser.parse_args()
    docs = load_wikipedia_docs()
    print(f"Checkpoint 5.1 | scenario: {SCENARIO} | local articles: {len(docs)}")
    agent = WikipediaToolUsingAgent(WikipediaRetriever(docs), make_llm(), debug=not args.no_debug)
    if args.question:
        answer = agent.query(args.question)
        print(f"\nAnswer:\n{answer}\n\nAgent plan:\n{json.dumps(my_agent_plan(), indent=2)}")
        log("AGENTIC", f"Q: {args.question}\nA: {answer}")
    else: agent.chat()


if __name__ == "__main__":
    main()
