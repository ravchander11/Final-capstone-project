# Maintenance Notes — Wikipedia Tool-Using RAG Agent

## Scope

`capstone_checkpoint_5_1_agent_rag_starter.py` is the current Capstone Checkpoint 5.1
implementation. It uses the local `Wikipedia/` corpus; it does not use the e-mail corpus
or date tool from the Lab 5.2 demonstration.

## Workflow contract

The LangGraph state carries conversation history, clarifications, pending tool inputs,
completed actions, collected articles, iteration count, and the final answer. The graph
routes `plan` to `search`, `article`, `links`, `clarify`, or `answer`; every tool except
`answer` returns control to `plan`.

Keep these safeguards intact when changing the workflow:

1. The first turn must run a local retrieval before an LLM planner may answer.
2. `answer_node` must not call the LLM when `articles` is empty.
3. Keep `MAX_ITERATIONS`, `TOP_K`, `MAX_CONTEXT_ARTICLES`, and `MAX_ARTICLE_CHARS`
   bounded so a planner error cannot create a loop or exceed context limits.
4. Treat planner rationale as unverified control-flow text, never as cited evidence.

## Corpus assumptions

- Articles are individual `.html` files in `Wikipedia/`.
- File names are article identifiers, for example `1984_NBA_Finals.html`.
- Local links must have a `/wiki/` path and a target file present in the same directory.
- `load_wikipedia_docs()` deliberately strips HTML, scripts, and styles before retrieval.

If the corpus changes, run a retrieval-only smoke check before using the agent:

```bash
python -B - <<'PY'
import importlib.util
import sys
from pathlib import Path

path = Path("capstone_checkpoint_5_1_agent_rag_starter.py")
spec = importlib.util.spec_from_file_location("checkpoint", path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
docs = module.load_wikipedia_docs()
retriever = module.WikipediaRetriever(docs)
print(f"articles: {len(docs)}")
print(retriever.find_article("1984 NBA Finals"))
print(retriever.search("Who won the 1984 NBA Finals?"))
PY
```

## Configuration and secrets

Set `OPENROUTER_API_KEY` in `Module 5/.env` or export it in the shell. Do not commit
`.env` files or API keys. The implementation expects OpenRouter credentials beginning
with `sk-or-`; a missing or invalid value produces a setup error before an LLM call.

## Verification after code changes

Run these checks from `Module 5/`:

```bash
python -m py_compile capstone_checkpoint_5_1_agent_rag_starter.py
python capstone_checkpoint_5_1_agent_rag_starter.py --question "Who won the 1984 NBA Finals?"
```

For a meaningful evaluation, compare the same test cases against the Checkpoint 2.1
fixed pipeline. Preserve the agent debug output and `checkpoint_5_1_agent.log` as
evidence of retrieval actions, then record answer quality, grounding, latency, model
calls, and cost.
