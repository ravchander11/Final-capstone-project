# Module 5 — Wikipedia Tool-Using RAG Agent

This implementation completes Capstone Checkpoint 5.1 with a LangGraph agent that
answers questions from the local Wikipedia HTML corpus. It adapts the Lab 5.2 planner
pattern to Wikipedia rather than the lab's e-mail data.

## What it does

The agent works in a loop: `plan → tool → plan → answer`. The planner receives the
question, prior conversation, completed actions, and collected articles, then chooses
one action in JSON.

| Action | Purpose |
| --- | --- |
| `search` | Lexical search across the local Wikipedia articles. |
| `article` | Deterministic lookup of a named article title. |
| `links` | Retrieve up to four local articles linked by a retrieved article. |
| `clarify` | Ask a follow-up question only after retrieval has not resolved an ambiguity. |
| `answer` | Create a cited answer using collected local articles. |

The corpus is in `Wikipedia/` and currently contains 2,419 HTML articles. The
retriever removes HTML markup, extracts titles, and preserves local `/wiki/` links for
one-hop traversal.

## Grounding safeguards

The refined workflow addresses a failure discovered during evaluation: an LLM planner
can use pretrained knowledge before it has retrieved corpus evidence.

- The first action is a mandatory local-corpus search; the planner cannot answer first.
- A request that retrieves no articles returns an explicit insufficient-evidence message
  without calling the answer model.
- Planner rationale is labelled as a tool-choice explanation, not evidence.
- The answer prompt requires article-title citations and prohibits outside knowledge.
- Retrieval is bounded by five tool iterations, four results per tool call, eight context
  articles, and 6,000 characters per article.

These guardrails improve grounding and transparency, while adding some latency compared
with the fixed one-pass Checkpoint 2.1 retriever.

## Setup

Use Python 3.11 or 3.12 and install the pinned dependencies:

```bash
cd "Module 5"
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Create `Module 5/.env` with a valid OpenRouter key:

```env
OPENROUTER_API_KEY=sk-or-v1-...
```

The program validates that the configured key begins with `sk-or-`. An exported
`OPENROUTER_API_KEY` environment variable takes precedence over values loaded from
`.env`.

## Run

Interactive chat:

```bash
python capstone_checkpoint_5_1_agent_rag_starter.py
```

One question, suitable for repeatable evaluation:

```bash
python capstone_checkpoint_5_1_agent_rag_starter.py \
  --question "Who won the 1984 NBA Finals, and whom did they defeat?"
```

Add `--no-debug` to hide action decisions. Successful runs append questions and answers
to `checkpoint_5_1_agent.log` in this directory.

## Suggested evaluation cases

Compare the agent to the fixed Checkpoint 2.1 lexical pipeline using the same questions:

1. `Who won the 1984 NBA Finals, and whom did they defeat?`
2. `What caused the 1955 Le Mans disaster and what safety changes followed?`
3. `How did the 1964 Alaska earthquake compare with other major earthquakes?`

The fixed pipeline is usually faster for direct entity questions. The agent is designed
to help with multi-part questions by collecting further articles through a second search,
exact title lookup, or local-link traversal. Record answer grounding and completeness,
retrieved articles, action count, model calls, latency, and cost for each test case.

## Repository contents

```text
Module 5/
├── capstone_checkpoint_5_1_agent_rag_starter.py  # implementation
├── Wikipedia/                                    # local HTML corpus
├── requirements.txt                               # runtime dependencies
├── docs-MAINTAINING.md                            # implementation and maintenance notes
└── README-5.md                                    # this guide
```
