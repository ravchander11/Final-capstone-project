# Capstone Checkpoint 4.1 — Advanced Wikipedia Retrieval

This project implements an advanced retrieval workflow over a local Wikipedia HTML corpus. It compares a lexical baseline with query decomposition and relationship-aware graph retrieval, grounds LLM answers in retrieved articles, and uses the Checkpoint 3.1 pass/fail evaluation framework for comparison.

Files included:
- `capstone_checkpoint_3_1_evaluation_starter.py` — baseline evaluation framework
- `capstone_checkpoint_4_1_advanced_retrieval_starter.py` — advanced retrieval implementation and demo
- `Wikipedia/` — local corpus of Wikipedia HTML articles used for testing
- `README.md` — project overview and usage
- `docs-MAINTAINING.md` — maintenance notes and validation workflow
- `requirements.txt` — Python dependencies
- `checkpoint_3_1_evaluation.log` — baseline evaluation evidence
- `checkpoint_4_1_responses.log` — advanced retrieval answer evidence

## Current implementation

The implementation uses the local `Wikipedia/` directory and performs the following steps:

- `load_wikipedia_docs()` cleans HTML, extracts article titles, and maps local `/wiki/` links to article files.
- `baseline_retrieve()` performs lexical overlap scoring over all articles and gives title matches double weight.
- `decompose_query()` asks the LLM to split complex questions into focused sub-queries.
- `multistep_retrieve()` retrieves for each sub-query and fuses scores across the result sets.
- `build_graph()` creates article nodes and directed `hyperlink` edges.
- `graph_retrieve()` starts with lexical seed articles, follows one hyperlink hop, labels results as `seed` or `linked`, ranks them by relevance, and caps the result set at `2 * k`.
- `answer_from_docs()` sends bounded article context to the LLM with grounding instructions.
- `my_advanced_plan()` records the selected strategy and evaluation queries for the worksheet.

The graph contains 2,419 article nodes and approximately 25,752 local hyperlink edges for the bundled corpus.

This makes it suitable for baseline diagnosis before adding more advanced retrieval or architecture changes.

## Running the advanced demo

From the project root:

```bash
python capstone_checkpoint_4_1_advanced_retrieval_starter.py
```

Make sure a local `.env` file exists with your OpenRouter API key:

```bash
OPENROUTER_API_KEY=sk-or-...
```

The demo compares baseline, multi-step, and graph retrieval for the query configured in `run_demo()`. Change the `query` value there to test another corpus question. The script requires an OpenRouter API key because decomposition and answer generation use the configured LLM.

## Evaluation workflow

The Checkpoint 3.1 evaluator uses four questions, generated answers, and an LLM judge that returns `pass` or `fail` against grading notes. Baseline evidence is stored in `checkpoint_3_1_evaluation.log`; advanced answer evidence is stored in `checkpoint_4_1_responses.log`.

The advanced demo runs as follows:

1. loads the local Wikipedia corpus
2. builds the article hyperlink graph
3. retrieves baseline, decomposed, and graph-expanded results
4. asks the LLM to answer using only bounded retrieved context
5. logs the graph-augmented answer and retrieval plan

For a full baseline evaluation, run:

```bash
python capstone_checkpoint_3_1_evaluation_starter.py
```

## Evaluation evidence

The latest comparable evaluation produced:

- baseline pass rate: 3/4 (75%)
- updated graph-retrieval pass rate: 2/4 (50%)

The updated system corrected the NBA retrieval example: `1984_NBA_Finals.html` became the top seed and the answer correctly identified the Boston Celtics. The lower overall score shows that hyperlink expansion still needs stronger filtering: it added noisy context for the Le Mans query and caused the unsupported 2024 election case to be answered rather than rejected.

These results are diagnostic rather than proof that graph retrieval is always better. They show improved recall for one failure mode alongside remaining precision and corpus-scope problems.

## Notes

- This project uses the local Wikipedia HTML corpus bundled in the `Wikipedia/` directory.
- The evaluation set intentionally mixes answerable questions with unsupported or failure-case questions to diagnose retrieval weaknesses.
- The advanced system intentionally limits graph context to `2 * k` documents, but linked documents can still be loosely related.
- The evaluation grading notes must match the actual corpus scope. If an article exists locally, an unsupported-query grading note may need to be revised.
- Install dependencies in the selected Python environment so VS Code can resolve `networkx`.
