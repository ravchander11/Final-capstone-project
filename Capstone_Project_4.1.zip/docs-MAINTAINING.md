# Maintaining this project

This file tracks the operational notes for the current Capstone Checkpoint 4.1 advanced Wikipedia retrieval implementation.

1. Update dependencies

- Edit `requirements.txt` when new runtime libraries are needed.
- Reinstall dependencies with:

```bash
pip install -r requirements.txt
```

2. Keep the corpus and scenario aligned with the code

- The current implementation targets the local Wikipedia corpus in `Wikipedia/`.
- Preserve the baseline comparison in `baseline_retrieve()` when changing the advanced strategy.
- `load_wikipedia_docs()` depends on filenames matching decoded Wikipedia article titles.
- Hyperlink edges are local, directed article-to-article relationships. Non-local links and missing local targets are ignored.
- Keep answer generation grounded in retrieved documents only.
- If the corpus or evaluation questions change, update `my_eval_set()` and rerun both baseline and advanced comparisons.

3. Run validation locally

```bash
python -m py_compile capstone_checkpoint_4_1_advanced_retrieval_starter.py
python capstone_checkpoint_4_1_advanced_retrieval_starter.py
python capstone_checkpoint_3_1_evaluation_starter.py
```

The advanced script invokes the LLM and requires `OPENROUTER_API_KEY`. The compile check does not require an API key.

4. Logging and evidence

- The baseline evaluator logs questions, retrieved documents, verdicts, and answers to `checkpoint_3_1_evaluation.log`.
- The advanced demo logs graph-augmented answers to `checkpoint_4_1_responses.log`.
- Use the printed retrieval sets and both logs as evidence for the checkpoint worksheet.
- The evaluation script performs framework validation by checking that a correct answer passes and a manipulated answer fails.

5. Current implementation notes

- The baseline is lexical overlap over cleaned article text with a 2x title-match weight.
- Query decomposition retrieves several focused sub-queries and sums document scores across them.
- Graph retrieval expands top lexical seeds through one hyperlink hop, labels sources, ranks candidates, and caps output at `2 * k`.
- The LLM answer step is grounded in bounded retrieved context, but graph expansion can expose facts outside an intended evaluation subset.
- The judge is a pass/fail evaluator based on grading notes; those notes must reflect the actual corpus and desired abstention behavior.
- Latest evidence: 2,419 articles and approximately 25,752 hyperlink edges; baseline 3/4 versus updated graph evaluation 2/4.

6. Documentation updates

- Add short notes here whenever the evaluation set, corpus, prompts, scoring, graph budget, or validation logic changes.
- Keep entries factual and concise so they remain useful for later checkpoints.

7. Committing changes

- Commit code and documentation together with a clear message such as: `Update Wikipedia evaluation baseline and docs`.
