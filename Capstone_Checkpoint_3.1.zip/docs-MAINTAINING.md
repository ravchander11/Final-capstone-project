# Maintaining this project

This file tracks the operational notes for the current Capstone Checkpoint 3.1 evaluation implementation.

1. Update dependencies

- Edit `requirements.txt` when new runtime libraries are needed.
- Reinstall dependencies with:

```bash
pip install -r requirements.txt
```

2. Keep the evaluation scenario aligned with the code

- The current implementation targets the local Wikipedia corpus in `Wikipedia/`.
- Preserve the baseline retrieval logic in `retrieve()` and ensure the answer-generation step remains grounded in the retrieved documents only.
- If the corpus or evaluation questions change, update `my_eval_set()` and validate the results again.

3. Run validation locally

```bash
python capstone_checkpoint_3_1_evaluation_starter.py
```

4. Logging and evidence

- The script logs each question, retrieved documents, verdict, and answer to `checkpoint_3_1_evaluation.log`.
- Use the printed output and the log file as evidence for the checkpoint worksheet.
- The evaluation script also performs framework validation by checking that a correct answer passes and a manipulated answer fails.

5. Current implementation notes

- The baseline retrieval is a lexical overlap scorer over cleaned Wikipedia HTML content.
- The LLM answer step is grounded only in the retrieved documents and refuses to guess when the corpus is missing the fact.
- The judge is a strict pass/fail evaluator based on grading notes.
- The project is designed for baseline diagnosis before introducing deeper optimization or architectural complexity.

6. Documentation updates

- Add short notes here whenever the evaluation set, corpus, prompt, or validation logic changes.
- Keep entries factual and concise so they remain useful for later checkpoints.

7. Committing changes

- Commit code and documentation together with a clear message such as: `Update Wikipedia evaluation baseline and docs`.
