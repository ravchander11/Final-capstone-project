# Capstone Checkpoint 3.1 — Evaluation Infrastructure and Baseline Diagnosis

This project implements the required evaluation workflow for a baseline Wikipedia retrieval system. It uses a local corpus of Wikipedia HTML pages, retrieves the top matching pages for a query, grounds the LLM answer in those documents, and scores answers with a strict pass/fail judge based on grading notes.

Files included:
- `capstone_checkpoint_3_1_evaluation_starter.py` — main evaluation script for the Wikipedia scenario
- `Wikipedia/` — local corpus of Wikipedia HTML articles used for testing
- `README.md` — project overview and usage
- `docs-MAINTAINING.md` — maintenance notes and validation workflow
- `requirements.txt` — Python dependencies
- `checkpoint_3_1_evaluation.log` — generated evaluation evidence from each run

## Current implementation

The current baseline system is intentionally simple and diagnostic:

- `retrieve()` performs lexical overlap scoring over the cleaned Wikipedia documents
- `answer()` builds a context window from the top retrieved documents and answers using only that evidence
- `judge()` evaluates the final response against explicit grading notes and returns `pass` or `fail`
- `my_eval_set()` defines a small evaluation set with both answerable and failure-mode questions
- `validate_framework()` checks that the judge accepts a correct answer and rejects a manipulated answer

This makes it suitable for baseline diagnosis before adding more advanced retrieval or architecture changes.

## Running the script

From the project root:

```bash
python capstone_checkpoint_3_1_evaluation_starter.py
```

Make sure a local `.env` file exists with your OpenRouter API key:

```bash
OPENROUTER_API_KEY=sk-or-...
```

If the key is missing, the script raises a clear setup error before running the evaluation.

## Evaluation workflow

When the script runs, it:

1. loads the local Wikipedia corpus
2. retrieves the top relevant documents for each question
3. asks the LLM to answer using only those documents
4. applies the pass/fail judge to the answer against the grading notes
5. logs the retrieved docs, verdict, and answer for review
6. validates the judge using a deliberately manipulated answer

## Verified baseline behavior

The evaluation was run successfully in this workspace and produced:

- baseline pass rate: 3/4
- correct answer validation: PASS
- manipulated answer validation: FAIL

This confirms the baseline evaluation framework is working as intended for detecting both valid evidence-grounded answers and bad or manipulated outputs.

## Notes

- This project uses the local Wikipedia HTML corpus bundled in the `Wikipedia/` directory.
- The evaluation set intentionally mixes answerable questions with unsupported or failure-case questions to diagnose retrieval weaknesses.
- The script is designed for structured baseline assessment before optimization or architectural complexity is introduced.
